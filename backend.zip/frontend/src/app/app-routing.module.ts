import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddfeedComponent } from './addfeed/addfeed.component';
import { HomeComponent } from './home/home.component';
import { ListfeedComponent } from './listfeed/listfeed.component';

const routes: Routes = [

  {path:'home', component:HomeComponent},
  {path:'addfeed', component:AddfeedComponent},

  {path:'listfeed', component:ListfeedComponent},
  // {path:'edit-user', component:EditUserComponent},
  // {path:'delete', component:DeleteComponent},

  //{path:'**', component:HomeComponent},
  // {
  //   path: '', component:HomeComponent
  // },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
