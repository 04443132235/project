import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '../../../node_modules/@angular/forms';
import { UserService } from '../../services/user.service';
import { Router } from '../../../node_modules/@angular/router';

@Component({
  selector: 'app-addfeed',
  templateUrl: './addfeed.component.html',
  styleUrls: ['./addfeed.component.css']
})
export class AddfeedComponent implements OnInit {

  // constructor() { }

  // ngOnInit() {
  // }

  addForm:  FormGroup;
  submitted: boolean=false;
 
  constructor(private formBuilder:FormBuilder , private router: Router,
  private userService:UserService) { }

  ngOnInit() {
    this.addForm=this.formBuilder.group({
    
      cmob:['' ,[Validators.required],[Validators.pattern('[7-9]{1}[0-9]{9}')]],
      productId:['' , Validators.required ],
      productName:['' ,[Validators.required]],
      reviews:['' , Validators.required ]
    });
  }

  //onSubmit() Function

  onSubmit()
  {
    this.submitted=true;
    if(this.addForm.invalid){
      return;
    }
    console.log(this.addForm.value);

    this.userService.create(this.addForm.value).subscribe(data=>{
      alert(this.addForm.controls.reviews.value +`record is added succesfully...!`);
      this.router.navigate(['/listfeed']);
    })
  }


}
