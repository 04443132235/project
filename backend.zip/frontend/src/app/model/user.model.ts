export class User
{
    cmob:number;
    productId:number;
    productName:string;
    reviews:string;
}