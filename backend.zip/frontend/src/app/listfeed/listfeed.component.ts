import { Component, OnInit } from '@angular/core';
import { User } from '../model/user.model';
import { Router } from '../../../node_modules/@angular/router';
import { UserService } from '../../services/user.service';


@Component({
  selector: 'app-listfeed',
  templateUrl: './listfeed.component.html',
  styleUrls: ['./listfeed.component.css']
})
export class ListfeedComponent implements OnInit {

  // constructor() { }

  // ngOnInit() {
  // }

  users:User[];



 constructor(private router:Router,

 private userService:UserService) { }

// loading all users as soon as component

//gets loaded

 ngOnInit() {

  this.userService.getFeeds()

  .subscribe(data=>{ //subscribe method observes all the changes and update teh changes

  //this.products = this.products.filter(u=> u!==product);

  this.users=data

   });

  }

  // else{

  //  this.router.navigate(['/listfeed']);

  // }

 







 //add user

 addFeedback():void{

  this.router.navigate(['addfeed']);

 }


}


