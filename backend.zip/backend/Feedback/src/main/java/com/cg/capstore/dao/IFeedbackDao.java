package com.cg.capstore.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.cg.capstore.entitites.Feedback;


@Repository
public interface IFeedbackDao extends JpaRepository<Feedback,Integer> {

	/*@Modifying
    @Query("UPDATE Product c SET c.feedback = :fb WHERE c.name = :pname")
	public Product addFeedback ( @PathVariable (value="pname") String pname, @PathVariable (value="fb") String fb );*/
	/*@Query(value = "SELECT f FROM feedback f INNER JOIN Product ON Product.id=(:id)",nativeQuery=true)
	public Feedback getFeedBack(@Param("id") int id);
	@Query(value = "SELECT f FROM feedback f INNERJOIN Product ON Product.id=(:id)",nativeQuery=true)
	public List<Feedback> getFeedBackList(@Param(value="id") int id);*/

	 /*@Query("select p from Feedback p where p.productName=:name")
	 public  Feedback getreviews(@Param("name") String productName);*/

	/*SELECT Orders.OrderID, Customers.CustomerName, Orders.OrderDate
	FROM Orders
	INNER JOIN Customers ON Orders.CustomerID=Customers.CustomerID;*/

	
	
}
