/*package com.cg.capstore.entitites;

public class Feedback {

}
*/
package com.cg.capstore.entitites;
import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
@Entity
@Table(name="feedbacks")

public class Feedback implements Serializable{
	
	

	//@NotNull
	@Column(name="cmob", length=20)

	private Long cmob;
	@NotNull
	
	@Id
	@Column(name="productid", unique=true, length=20)
	//@GeneratedValue(strategy=GenerationType.AUTO)
	
	private Integer productId;
	
	//@OneToOne()
	//Customer customer;
	/*@ManyToOne(targetEntity=Product.class)
	@JoinColumn(name="prodname")
	private Product product;*/
	
	//@NotNull
	@Column(name="productname", length=20 , nullable=false)
	private String productName;
	//@NotNull
	@Column(name="reviews", length=50,nullable=false)
	private String reviews;
	


	

	
	

	public Long getCmob() {
		return cmob;
	}

	public void setCmob(Long cmob) {
		this.cmob = cmob;
	}

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getReviews() {
		return reviews;
	}

	public void setReviews(String reviews) {
		this.reviews = reviews;
	}
	
	public Feedback() {
		// TODO Auto-generated constructor stub
	}

	/*public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}*/

	@Override
	public String toString() {
		return "Feedback [cmob=" + cmob + ", productId=" + productId + ", productname=" + productName + ", reviews=" + reviews + "]";
	}

	/*public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}*/

	

	

}
